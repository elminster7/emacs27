class Foo
{
public:
    int get()
    {
        return 12;
    }

private:
    void validate(int)
    {
        this->
    }
};


int main()
{
    Foo f;
    f.
}
