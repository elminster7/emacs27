#include "../sub1/export/sub1.hpp"
#include <stdlib.h>

int main(void)
{
    int v=SUB1MOD::Csub1::sub1(1);

    return SUB1MOD::fcn1(v);
}
