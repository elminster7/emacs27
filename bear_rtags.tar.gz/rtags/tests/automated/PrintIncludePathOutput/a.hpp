#pragma once

void bar() {};
