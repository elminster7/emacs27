#include "a.hpp"

void foo() {
    bar();
}
