void free_function() {}

void foo() {
    free_function();
    free_function();
}

