#include "foo.h"

int main(int, char**)
{
    // foo();
    return 0;
}
