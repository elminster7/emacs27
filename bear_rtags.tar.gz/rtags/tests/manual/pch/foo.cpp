#include "foo.h"

extern "C"
void foo()
{
}
