#pragma once

#define HAVE_EXECVE
#define HAVE_EXECV
#define HAVE_EXECVPE
#define HAVE_EXECVP
/* #undef HAVE_EXECVP2 */
/* #undef HAVE_EXECT */
#define HAVE_EXECL
#define HAVE_EXECLP
#define HAVE_EXECLE
#define HAVE_POSIX_SPAWN
#define HAVE_POSIX_SPAWNP
/* #undef HAVE_NSGETENVIRON */

/* #undef APPLE */
