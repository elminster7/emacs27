#include "foo.h"

namespace acme
{

void b1()
{
    t1();
}

}
