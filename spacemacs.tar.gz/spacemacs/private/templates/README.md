# Private directory for Yatemplate templates

The content of this directory is ignored by Git. This is the default place
where to store your private templates.

This path will be loaded automatically and used whenever Yatemplate loads.
